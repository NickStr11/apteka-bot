// Настройки расширения
const CONFIG = {
    // VPS сервер (для localhost: http://localhost:5000/api/order)
    API_URL: 'http://194.87.140.204:5000/api/order'
};
